package HPC2.ARS;

import HPC2.optimize.AllocResult;

import java.util.Map;

/**
 * start from 15/2/5.
 */
public class EmptyDecisionMaker implements DecisionMaker {
    @Override
    public Map<String, Integer> make(AllocResult newAllocResult, Map<String, Integer> currAlloc) {
        return null;
    }
}
