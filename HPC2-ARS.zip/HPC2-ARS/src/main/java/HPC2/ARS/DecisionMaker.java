package HPC2.ARS;

import org.apache.storm.generated.StormTopology;
import HPC2.optimize.AllocResult;

import java.util.Map;

/**
 * 16-6-20.
 */
public interface DecisionMaker {

    /**
     * Called when a new instance was created.
     *
     * @param conf
     * @param rawTopology
     */
    default void init(Map<String, Object> conf, StormTopology rawTopology) {
    }

    Map<String, Integer> make(AllocResult newAllocResult, Map<String, Integer> currAlloc);


}
