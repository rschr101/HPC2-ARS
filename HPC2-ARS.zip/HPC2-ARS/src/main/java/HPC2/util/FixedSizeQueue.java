package HPC2.util;

import java.util.LinkedList;

/**
 * 16-4-30.
 */
public class FixedSizeQueue extends LinkedList {

    public FixedSizeQueue(int maxSize) {
        this.maxSize = maxSize;
    }

    private int maxSize;

    @Override
    public boolean add(Object o) {
        boolean ret = super.add(o);
        if (size() > maxSize) {
            poll();
        }
        return ret;
    }
}
