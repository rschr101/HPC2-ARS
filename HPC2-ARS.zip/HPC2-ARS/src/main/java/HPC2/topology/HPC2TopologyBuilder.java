package HPC2.topology;

import org.apache.storm.topology.*;
import HPC2.metrics.MeasurableBolt;
import HPC2.metrics.MeasurableSpout;

/**
 * 16-4-26.
 */
public class HPC2TopologyBuilder extends TopologyBuilder {

    @Override
    public BoltDeclarer setBolt(String id, IRichBolt bolt, Number parallelismHint) {
        bolt = new MeasurableBolt(bolt);
        return super.setBolt(id, bolt, parallelismHint);
    }

    @Override
    public SpoutDeclarer setSpout(String id, IRichSpout spout, Number parallelismHint) {
        spout = new MeasurableSpout(spout);
        return super.setSpout(id, spout, parallelismHint);
    }
}
