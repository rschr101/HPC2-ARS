package TestTopology.helper;

import java.io.Serializable;

/**
 * 16-4-15.
 */
public interface IntervalSupplier extends Serializable {

    long get();

}
